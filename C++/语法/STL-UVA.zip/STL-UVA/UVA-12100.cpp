#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <algorithm>
#define MAXN 1010
#define MAXSIZE 500010
#define EPS 0.000001
using namespace std;

int main() {
    int n, m, t, aim;
    priority_queue<int> pq;
    queue<int> q;

    scanf("%d", &t);
    while (t--) {
        scanf("%d%d", &n, &m);
        aim = m;

        int x;
        for (int i = 0; i < n; i++) {
            scanf("%d", &x);
            pq.push(x);
            q.push(x);
        }
        int ans = 0;
        while (true) {
            int front = q.front(), top = pq.top();
            q.pop();
            if (front < top) {
                q.push(front);
                if (aim == 0) {
                    aim = (int)q.size() - 1;
                } else {
                    aim--;
                }
            } else {
                ans++;
                pq.pop();
                if (aim == 0) {
                    printf("%d\n", ans);
                    break;
                } else {
                    aim--;
                }
            }
        }

        while (!pq.empty()) {
            pq.pop();
        }
        while (!q.empty()) {
            q.pop();
        }
    }

    return 0;
}

