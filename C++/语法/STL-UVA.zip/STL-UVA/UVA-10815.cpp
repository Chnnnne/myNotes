#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <cmath>
#include <algorithm>
#define MAXN 1010
#define MAXSIZE 500010
#define EPS 0.000001
using namespace std;

int main() {
    string word;
    set<string> dict;

    while (cin >> word) {
        string cur = "";
        for (int i = 0; i < word.length(); i++) {
            if (isalpha(word[i])) {
                cur += tolower(word[i]);
            } else if (cur != "") {
                dict.insert(cur);
                cur = "";
            }
        }
        if (cur != "") {
            dict.insert(cur);
        }
    }

    for (set<string>::iterator it = dict.begin(); it != dict.end(); it++) {
        cout << *it << endl;
    }

    return 0;
}

