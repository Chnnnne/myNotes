#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
#include <queue>
#include <algorithm>
#define MAXN 1010
#define MAXSIZE 200
using namespace std;

int main() {
    int n;
    queue<int> q;

    while (scanf("%d", &n) && n != 0) {
        for (int i = 1; i <= n; i++) {
            q.push(i);
        }
        printf("Discarded cards:");
        while (q.size() > 1) {
            printf(" %d", q.front());
            q.pop();
            int front = q.front();
            q.pop();
            if (!q.empty()) {
                printf(",");
            }
            q.push(front);
        }
        printf("\nRemaining card: %d\n", q.front());
        q.pop();
    }

    return 0;
}
